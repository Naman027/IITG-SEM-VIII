function ret = f(x, y, z)
    ret = -2*((1-y.*y).*(1-z.*z)+(1-x.*x).*(1-z.*z)+(1-x.*x).*(1-y.*y));
end

