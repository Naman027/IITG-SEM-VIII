function L = RHS(node, intNodeIndex, h)
    intNode = node(intNodeIndex, :);
    if size(h) == 1
        h = [h, h, h];
    end
    L = f(intNode(:, 1), intNode(:, 2), intNode(:, 3))*h(1)*h(2)*h(3);
end

