function A = LHS(node,elem,intNodeIndex,h)
    N = size(node, 1);
    if size(h) == 1
        h = [h,h,h];
    end
    intFlag = ismember(1:N, intNodeIndex);
    itgrl = zeros(N, N);
    dphi = [1,0,0;0,1,0;0,0,1;-1,-1,-1];
    for i = 1:size(elem, 1)
        loc = elem(i, :);
        F = [node(loc(1),1)-node(loc(4),1),node(loc(2),1)-node(loc(4),1),node(loc(3),1)-node(loc(4),1); ...
            node(loc(1),2)-node(loc(4),2),node(loc(2),2)-node(loc(4),2),node(loc(3),2)-node(loc(4),2); ...
            node(loc(1),3)-node(loc(4),3),node(loc(2),3)-node(loc(4),3),node(loc(3),3)-node(loc(4),3)];
        for j = 1:4
            if ~intFlag(loc(j))
                continue;
            end
            for k = 1:4
                if ~intFlag(loc(k))
                    continue;
                end
                dphij = dphi(j,:)/F;
                dphik = dphi(k,:)/F;
                calc = dot(dphij, dphik)*h(1)*h(2)*h(3)/6;
                itgrl(loc(k), loc(j)) = itgrl(loc(k), loc(j)) + calc;
            end
        end
    end
    A = itgrl(intNodeIndex,intNodeIndex);
end

