function val = u(node,intNodeIndex)
    val = -(1-node(intNodeIndex,1).*node(intNodeIndex,1)).*(1-node(intNodeIndex,2).*node(intNodeIndex,2)).*(1-node(intNodeIndex,3).*node(intNodeIndex,3));
end

