function T = auxstructure3(elem)
    totalFace = uint32(sort([elem(:,[2 3 4]); elem(:,[1 4 3]);...
        elem(:,[1 2 4]); elem(:,[1 3 2])], 2));
    [face, i_tot_last, i_face] = myunique(totalFace);
    NT = size(elem, 1);
    elem2face = uint32(reshape(i_face, NT, 4));
    i_tot_first(i_face(4*NT:-1:1)) = 4*NT:-1:1;
    i_tot_first = i_tot_first';
    first_elem_face = ceil(i_tot_first/NT);
    last_elem_face = ceil(i_tot_last/NT);
    first_elem = i_tot_first - NT*(first_elem_face-1);
    last_elem = i_tot_last - NT*(last_elem_face-1);
    diff_ind = (i_tot_first ~= i_tot_last);
    neighbor = uint32(accumarray([[first_elem(diff_ind) first_elem_face(diff_ind)];...
        [last_elem last_elem_face]], [last_elem(diff_ind); first_elem], [NT 4]));
    face2elem = uint32([first_elem last_elem first_elem_face last_elem_face]);
    bdElem = first_elem(first_elem == last_elem);
    first_face_bd = first_elem_face(first_elem == last_elem);
    bdFace = uint32([elem(bdElem(first_face_bd==1),[2 3 4]); elem(bdElem(first_face_bd==2),[1 3 4]);...
        elem(bdElem(first_face_bd==3),[1 2 4]); elem(bdElem(first_face_bd==4),[1 3 2])]);
    bdFace2elem = uint32([bdElem(first_face_bd==1);bdElem(first_face_bd==2);...
        bdElem(first_face_bd==3);bdElem(first_face_bd==4)]);
    T = struct('neighbor',neighbor,'elem2face',elem2face,'face',uint32(face),...
        'face2elem',face2elem,'bdElem',bdElem,'bdFace',bdFace,'bdFace2elem', bdFace2elem);
end